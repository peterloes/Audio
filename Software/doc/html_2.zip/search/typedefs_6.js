var searchData=
[
  ['long',['LONG',['../d6/d3d/integer_8h.html#a27ec6163192f1e1e72d87421379ea3d4',1,'integer.h']]]
];
