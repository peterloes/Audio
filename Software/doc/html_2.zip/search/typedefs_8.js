var searchData=
[
  ['short',['SHORT',['../d6/d3d/integer_8h.html#a78509a33db204fd62f2f684019150cf8',1,'integer.h']]]
];
