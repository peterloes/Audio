var searchData=
[
  ['vcmp_5firqn',['VCMP_IRQn',['../d9/d34/group___e_f_m32_g230_f128.html#gga666eb0caeb12ec0e281415592ae89083ae51ac365d90523f2d68ec5689b4d1c9c',1,'efm32g230f128.h']]],
  ['vcmphyst20mv',['vcmpHyst20mV',['../d4/d35/group___v_c_m_p.html#ggab56ac68a10865bcbd08f2978a6cf5d5ba9c7ff466e5d4da40fcd034d880f0b334',1,'em_vcmp.h']]],
  ['vcmphystnone',['vcmpHystNone',['../d4/d35/group___v_c_m_p.html#ggab56ac68a10865bcbd08f2978a6cf5d5ba206e40abcd9cb83626a9ca4b4120c629',1,'em_vcmp.h']]],
  ['vcmpwarmtime128cycles',['vcmpWarmTime128Cycles',['../d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6a303d98df3d98f8f9cdb25e0a701e278b',1,'em_vcmp.h']]],
  ['vcmpwarmtime16cycles',['vcmpWarmTime16Cycles',['../d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6a0c3463a3df83eb595683def4fa3e191e',1,'em_vcmp.h']]],
  ['vcmpwarmtime256cycles',['vcmpWarmTime256Cycles',['../d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6a0629f788c0d6c46e0bc61a1890c7a927',1,'em_vcmp.h']]],
  ['vcmpwarmtime32cycles',['vcmpWarmTime32Cycles',['../d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6a40c1933761b44df612af15901ba3b3bd',1,'em_vcmp.h']]],
  ['vcmpwarmtime4cycles',['vcmpWarmTime4Cycles',['../d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6aa18bd07e3b064e80f710772c03ef6e16',1,'em_vcmp.h']]],
  ['vcmpwarmtime512cycles',['vcmpWarmTime512Cycles',['../d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6a3a70a500a360e8e46e0e27ff8d245061',1,'em_vcmp.h']]],
  ['vcmpwarmtime64cycles',['vcmpWarmTime64Cycles',['../d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6a7f759bfc3a0cd6061c9e56de13f90049',1,'em_vcmp.h']]],
  ['vcmpwarmtime8cycles',['vcmpWarmTime8Cycles',['../d4/d35/group___v_c_m_p.html#gga4d4b37ff688f47766c7f11fd44806cc6ab833ea0316d2729f828f44b3ebe2b4ba',1,'em_vcmp.h']]]
];
