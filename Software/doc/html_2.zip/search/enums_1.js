var searchData=
[
  ['bat_5flog_5finfo_5flvl',['BAT_LOG_INFO_LVL',['../df/db0/_battery_mon_8h.html#a4f5578fa2682984392a52eb067a5bff9',1,'BatteryMon.h']]]
];
