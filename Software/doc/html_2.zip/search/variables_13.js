var searchData=
[
  ['vddlevel',['vddLevel',['../d2/d52/struct_a_c_m_p___capsense_init___type_def.html#a75dbd54b3d3aff2ab2027807d07c678d',1,'ACMP_CapsenseInit_TypeDef::vddLevel()'],['../d5/d5b/struct_a_c_m_p___init___type_def.html#a75dbd54b3d3aff2ab2027807d07c678d',1,'ACMP_Init_TypeDef::vddLevel()']]],
  ['version',['Version',['../d3/d46/struct_p_r_j___i_n_f_o.html#a0a958e3c9b42e9776bb0cf231172aa33',1,'PRJ_INFO']]]
];
