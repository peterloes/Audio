var searchData=
[
  ['xfersprmsec',['xfersPrMsec',['../d4/d6f/microsd_8c.html#a296b5624d00c9a163a1f224db2cb93f3',1,'microsd.c']]]
];
