var searchData=
[
  ['get_5fblock_5fsize',['GET_BLOCK_SIZE',['../d3/d5d/diskio_8h.html#aec3bb4dfe075d0ba2f3b07b300a95500',1,'diskio.h']]],
  ['get_5fsector_5fcount',['GET_SECTOR_COUNT',['../d3/d5d/diskio_8h.html#a570216006f6a8fc4e1698b1bbb2d1dde',1,'diskio.h']]],
  ['get_5fsector_5fsize',['GET_SECTOR_SIZE',['../d3/d5d/diskio_8h.html#ac73b5cf2135cbd459d109b96c9aa346a',1,'diskio.h']]],
  ['gpio_5fbit_5faddr',['GPIO_BIT_ADDR',['../d2/d81/_control_8c.html#a85a066138b32e08d0665f75f6597dbfb',1,'Control.c']]],
  ['gpio_5fbit_5faddr_5fto_5fpin',['GPIO_BIT_ADDR_TO_PIN',['../d2/d81/_control_8c.html#a7f7b3e5058554a40125f69c6cfdf14ba',1,'Control.c']]],
  ['gpio_5fbit_5faddr_5fto_5fport',['GPIO_BIT_ADDR_TO_PORT',['../d2/d81/_control_8c.html#aaef3e8c4d4ecf623d9ed8e7c7508831a',1,'Control.c']]]
];
