var searchData=
[
  ['i2c_5finit_5ftypedef',['I2C_Init_TypeDef',['../df/d24/struct_i2_c___init___type_def.html',1,'']]],
  ['i2c_5ftransferseq_5ftypedef',['I2C_TransferSeq_TypeDef',['../d7/d2a/struct_i2_c___transfer_seq___type_def.html',1,'']]]
];
