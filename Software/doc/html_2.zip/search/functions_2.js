var searchData=
[
  ['batmontriggeralarm',['BatMonTriggerAlarm',['../d6/dae/_battery_mon_8c.html#ad5f2476e661031d474a7092625dbdfe8',1,'BatteryMon.c']]],
  ['batterycheck',['BatteryCheck',['../d6/dae/_battery_mon_8c.html#a8838c5f20aadbb18262e1f82a2d31599',1,'BatteryCheck(void):&#160;BatteryMon.c'],['../df/db0/_battery_mon_8h.html#a8838c5f20aadbb18262e1f82a2d31599',1,'BatteryCheck(void):&#160;BatteryMon.c']]],
  ['batteryinfoget',['BatteryInfoGet',['../d6/dae/_battery_mon_8c.html#a1cb57ee5b74fc125ef9000326a096b11',1,'BatteryInfoGet(void):&#160;BatteryMon.c'],['../df/db0/_battery_mon_8h.html#a1cb57ee5b74fc125ef9000326a096b11',1,'BatteryInfoGet(void):&#160;BatteryMon.c']]],
  ['batteryinforeq',['BatteryInfoReq',['../d6/dae/_battery_mon_8c.html#a914c6c76f36e13829e3a62e6e70c52f1',1,'BatteryInfoReq(SBS_CMD req_1, SBS_CMD req_2):&#160;BatteryMon.c'],['../df/db0/_battery_mon_8h.html#a914c6c76f36e13829e3a62e6e70c52f1',1,'BatteryInfoReq(SBS_CMD req_1, SBS_CMD req_2):&#160;BatteryMon.c']]],
  ['batterymondeinit',['BatteryMonDeinit',['../d6/dae/_battery_mon_8c.html#aa8a2d462a32f2aa69e24879e3aaf8447',1,'BatteryMonDeinit(void):&#160;BatteryMon.c'],['../df/db0/_battery_mon_8h.html#aa8a2d462a32f2aa69e24879e3aaf8447',1,'BatteryMonDeinit(void):&#160;BatteryMon.c']]],
  ['batterymoninit',['BatteryMonInit',['../d6/dae/_battery_mon_8c.html#aaf1f2ce34685b6b5b478d46408cbd942',1,'BatteryMonInit(void):&#160;BatteryMon.c'],['../df/db0/_battery_mon_8h.html#aaf1f2ce34685b6b5b478d46408cbd942',1,'BatteryMonInit(void):&#160;BatteryMon.c']]],
  ['batterymonpowerfailhandler',['BatteryMonPowerFailHandler',['../df/db0/_battery_mon_8h.html#ab80ce93e19f64ca232981f1f546ed24d',1,'BatteryMon.h']]],
  ['batteryregreadblock',['BatteryRegReadBlock',['../d6/dae/_battery_mon_8c.html#af2011633d8b0ce6b8df29fd45a65cf23',1,'BatteryRegReadBlock(SBS_CMD cmd, uint8_t *pBuf, size_t bufSize):&#160;BatteryMon.c'],['../df/db0/_battery_mon_8h.html#af2011633d8b0ce6b8df29fd45a65cf23',1,'BatteryRegReadBlock(SBS_CMD cmd, uint8_t *pBuf, size_t bufSize):&#160;BatteryMon.c']]],
  ['batteryregreadword',['BatteryRegReadWord',['../d6/dae/_battery_mon_8c.html#ac1663904a8da513427909e9bec50abf4',1,'BatteryRegReadWord(SBS_CMD cmd):&#160;BatteryMon.c'],['../df/db0/_battery_mon_8h.html#ac1663904a8da513427909e9bec50abf4',1,'BatteryRegReadWord(SBS_CMD cmd):&#160;BatteryMon.c']]],
  ['bitband_5fperipheral',['BITBAND_Peripheral',['../d7/db4/group___b_i_t_b_a_n_d.html#ga7df78ffd2c201e674a4444c42b6fcec3',1,'em_bitband.h']]],
  ['bitband_5fperipheralread',['BITBAND_PeripheralRead',['../d7/db4/group___b_i_t_b_a_n_d.html#ga7fb188d17a5b2e4e28752c5955c01bf3',1,'em_bitband.h']]],
  ['bitband_5fsram',['BITBAND_SRAM',['../d7/db4/group___b_i_t_b_a_n_d.html#gadeb8874cb6213945a0ab24d39fe3e425',1,'em_bitband.h']]],
  ['bitband_5fsramread',['BITBAND_SRAMRead',['../d7/db4/group___b_i_t_b_a_n_d.html#gab358ffddc290c3d773aaa149636969ea',1,'em_bitband.h']]]
];
