var searchData=
[
  ['rfid_5fdisplay_5fupdate_5fwhen_5fabsent',['RFID_DISPLAY_UPDATE_WHEN_ABSENT',['../d2/dba/_r_f_i_d_8h.html#a6403a545f800ef1aa57bd9aeede5d66f',1,'RFID.h']]],
  ['rfid_5ftriggered_5fby_5flight_5fbarrier',['RFID_TRIGGERED_BY_LIGHT_BARRIER',['../d2/dba/_r_f_i_d_8h.html#a5a4c0617d02e50b67c6da96c0dd5ec9f',1,'RFID_TRIGGERED_BY_LIGHT_BARRIER():&#160;RFID.h'],['../db/d16/config_8h.html#a5a4c0617d02e50b67c6da96c0dd5ec9f',1,'RFID_TRIGGERED_BY_LIGHT_BARRIER():&#160;config.h']]],
  ['rtc_5fcounts_5fper_5fsec',['RTC_COUNTS_PER_SEC',['../da/d26/_alarm_clock_8h.html#ada3f8846e8c541f89986d014bbdd3a5b',1,'RTC_COUNTS_PER_SEC():&#160;AlarmClock.h'],['../db/d16/config_8h.html#ada3f8846e8c541f89986d014bbdd3a5b',1,'RTC_COUNTS_PER_SEC():&#160;config.h']]]
];
