var _control_8h =
[
    [ "MOD_CONTROL_EXISTS", "dc/df5/_control_8h.html#a35c76734adfdd7f3fb52748c87881192", null ],
    [ "DFLT_CAM_DURATION", "dc/df5/_control_8h.html#af4debf0246de3fd8071219176ef46c22", null ],
    [ "DFLT_KEEP_OPEN_DURATION", "dc/df5/_control_8h.html#a0466182905061788e26ce531d89b5585", null ],
    [ "DFLT_KEEP_CLOSED_DURATION", "dc/df5/_control_8h.html#a7d0fd4aae4ecbbbe84ca0cb1b9a6b7fe", null ],
    [ "PWR_OFF", "dc/df5/_control_8h.html#ae573e39d21efb9429c66ed40238fd6b4", null ],
    [ "PWR_ON", "dc/df5/_control_8h.html#ace895878ac0c9c05686a269a095033c8", null ],
    [ "PWR_OUT", "dc/df5/_control_8h.html#a7b23656e08f57281c2492541245f8b25", [
      [ "PWR_OUT_NONE", "dc/df5/_control_8h.html#a7b23656e08f57281c2492541245f8b25a4384b4173969a727e51b16ca01a98d31", null ],
      [ "PWR_OUT_UA1", "dc/df5/_control_8h.html#a7b23656e08f57281c2492541245f8b25a7ce88afb782021adafad808eeef97b5d", null ],
      [ "PWR_OUT_UA2", "dc/df5/_control_8h.html#a7b23656e08f57281c2492541245f8b25a434c8186d2181fc31a385e53221645e9", null ],
      [ "PWR_OUT_VDD_SERVO", "dc/df5/_control_8h.html#a7b23656e08f57281c2492541245f8b25aad07007ee78301bb41a1cf19a9ef989e", null ],
      [ "PWR_OUT_VDD_LINEAR", "dc/df5/_control_8h.html#a7b23656e08f57281c2492541245f8b25a340c0725beeea6f6c74d7a0fd62fa7ba", null ],
      [ "PWR_OUT_VDD_RFID1", "dc/df5/_control_8h.html#a7b23656e08f57281c2492541245f8b25ada325e0a4ea74c91ae66837312437c21", null ],
      [ "PWR_OUT_VDD_RFID2", "dc/df5/_control_8h.html#a7b23656e08f57281c2492541245f8b25a56975e19fdd7961610000a81267de0ff", null ],
      [ "PWR_OUT_VDD_RFID3", "dc/df5/_control_8h.html#a7b23656e08f57281c2492541245f8b25ac3aa771300a8a76dd6393ceafb7e4f22", null ],
      [ "PWR_OUT_RFID_GND_LB", "dc/df5/_control_8h.html#a7b23656e08f57281c2492541245f8b25a930c4852d9f60c17d515ff05880356d2", null ],
      [ "NUM_PWR_OUT", "dc/df5/_control_8h.html#a7b23656e08f57281c2492541245f8b25a25b4c569b9542826dad96f80f87241be", null ]
    ] ],
    [ "ControlInit", "dc/df5/_control_8h.html#a6b08b89da482cdbc5a18743835b2d700", null ],
    [ "ClearConfiguration", "dc/df5/_control_8h.html#ad36751837af7ec22750c289b9b755bfb", null ],
    [ "ControlUpdateID", "dc/df5/_control_8h.html#abfad61d13191a6cd185361f64e0bd941", null ],
    [ "CameraEnable", "dc/df5/_control_8h.html#a4dc388b2e76256244988c546fd712884", null ],
    [ "CameraDisable", "dc/df5/_control_8h.html#a18598bd8ffd0398c09e778c91bd722b6", null ],
    [ "CameraTimedDisable", "dc/df5/_control_8h.html#abd6844f0420b0a2a7b10ca05b433e36b", null ],
    [ "PowerOutput", "dc/df5/_control_8h.html#a5516e9d442dcc67f7205c5f6c095f4f9", null ],
    [ "IsPowerOutputOn", "dc/df5/_control_8h.html#a9a7c3269f7b44d90b4b6aaa600e54bb6", null ],
    [ "ControlPowerFailHandler", "dc/df5/_control_8h.html#a3a7749219117b7b402d5c4515d6fe48d", null ],
    [ "g_enum_PowerOutput", "dc/df5/_control_8h.html#a40abdf6abc9b3d3cb83717170c9207b3", null ]
];