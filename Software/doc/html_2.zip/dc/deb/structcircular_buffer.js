var structcircular_buffer =
[
    [ "rdI", "dc/deb/structcircular_buffer.html#a4bb832e9d4116922a5a0272e05fd509b", null ],
    [ "wrI", "dc/deb/structcircular_buffer.html#a54aa5f6622dcc738c8be336836b02dfa", null ],
    [ "pendingBytes", "dc/deb/structcircular_buffer.html#ad3fc86eed7688298fb970c3dc3e330fe", null ],
    [ "overflow", "dc/deb/structcircular_buffer.html#a49aa97067a36875627e1380c3fb3833d", null ]
];