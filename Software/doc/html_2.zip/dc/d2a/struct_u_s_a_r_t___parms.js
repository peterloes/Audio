var struct_u_s_a_r_t___parms =
[
    [ "UART", "dc/d2a/struct_u_s_a_r_t___parms.html#aeb8a84c6e537db256b4fd04378c6e7a0", null ],
    [ "cmuClock_UART", "dc/d2a/struct_u_s_a_r_t___parms.html#a01474fd8e6899914a4fc53a9c6b8efef", null ],
    [ "UART_Rx_IRQn", "dc/d2a/struct_u_s_a_r_t___parms.html#a1a8f9ad65c6aeebd4ea3a5e2fe6bb70e", null ],
    [ "UART_Rx_Port", "dc/d2a/struct_u_s_a_r_t___parms.html#ad193cf756fb465dd99d257a76e017618", null ],
    [ "UART_Rx_Pin", "dc/d2a/struct_u_s_a_r_t___parms.html#a06f3599c959ee7cd87f1a0941f757a1e", null ],
    [ "UART_Route", "dc/d2a/struct_u_s_a_r_t___parms.html#a34f6e76fd4ca955f04bd1203fde184ad", null ]
];