var struct_t_i_m_e_r___init___type_def =
[
    [ "enable", "dd/dd1/struct_t_i_m_e_r___init___type_def.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
    [ "debugRun", "dd/dd1/struct_t_i_m_e_r___init___type_def.html#a95936f85c6ab1a7f43f02f15f172f1db", null ],
    [ "prescale", "dd/dd1/struct_t_i_m_e_r___init___type_def.html#aa4141060cfa878220706423874377f74", null ],
    [ "clkSel", "dd/dd1/struct_t_i_m_e_r___init___type_def.html#ab91daea221f98745ed8edfd037d04127", null ],
    [ "fallAction", "dd/dd1/struct_t_i_m_e_r___init___type_def.html#a702223fc5fe41c4d0c187163ad8fa73b", null ],
    [ "riseAction", "dd/dd1/struct_t_i_m_e_r___init___type_def.html#ad93aefc197750e645813aa3d66c4413f", null ],
    [ "mode", "dd/dd1/struct_t_i_m_e_r___init___type_def.html#a7303b82a377f4a010a918bc470b86f9a", null ],
    [ "dmaClrAct", "dd/dd1/struct_t_i_m_e_r___init___type_def.html#a34fe5c970ad22987e64ca56ac5ec911f", null ],
    [ "quadModeX4", "dd/dd1/struct_t_i_m_e_r___init___type_def.html#a534c41f8da6dca13a4d46d915de3b720", null ],
    [ "oneShot", "dd/dd1/struct_t_i_m_e_r___init___type_def.html#a582db6cb3f8bfc9ab78cb390d64d6a49", null ],
    [ "sync", "dd/dd1/struct_t_i_m_e_r___init___type_def.html#af5bad216eac9aefc703a450d3163e542", null ]
];