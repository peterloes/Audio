var struct_a_l_a_r_m___t_i_m_e =
[
    [ "Hour", "de/dfc/struct_a_l_a_r_m___t_i_m_e.html#af3ffd946118a86464b833c200fd7771d", null ],
    [ "Minute", "de/dfc/struct_a_l_a_r_m___t_i_m_e.html#ab8eb22c6d10c66ef4b9076af23182102", null ]
];