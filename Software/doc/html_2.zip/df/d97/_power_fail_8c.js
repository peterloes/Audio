var _power_fail_8c =
[
    [ "PowerFailInit", "df/d97/_power_fail_8c.html#a8973e466a8be8f83fc3691be6515e40f", null ],
    [ "PowerFailCheck", "df/d97/_power_fail_8c.html#aa15e398c01bdaff1bb8fbcef2a4fbab7", null ],
    [ "IsPowerFail", "df/d97/_power_fail_8c.html#a3dd98fd9e99b2d4d56fa7073df433667", null ],
    [ "PowerFailHandler", "df/d97/_power_fail_8c.html#ad3292b571af22c746e9a47dc6a40bafa", null ],
    [ "l_pPowerFailFct", "df/d97/_power_fail_8c.html#aadf5d7fa7cd862d99caba2be34f77282", null ],
    [ "l_flgPowerFail", "df/d97/_power_fail_8c.html#ad884781ff135f85e32312014bd89d944", null ]
];