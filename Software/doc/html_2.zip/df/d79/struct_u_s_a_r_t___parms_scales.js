var struct_u_s_a_r_t___parms_scales =
[
    [ "UART", "df/d79/struct_u_s_a_r_t___parms_scales.html#aeb8a84c6e537db256b4fd04378c6e7a0", null ],
    [ "cmuClock_UART", "df/d79/struct_u_s_a_r_t___parms_scales.html#a01474fd8e6899914a4fc53a9c6b8efef", null ],
    [ "UART_Rx_IRQn", "df/d79/struct_u_s_a_r_t___parms_scales.html#a1a8f9ad65c6aeebd4ea3a5e2fe6bb70e", null ],
    [ "UART_Rx_Port", "df/d79/struct_u_s_a_r_t___parms_scales.html#ad193cf756fb465dd99d257a76e017618", null ],
    [ "UART_Rx_Pin", "df/d79/struct_u_s_a_r_t___parms_scales.html#a06f3599c959ee7cd87f1a0941f757a1e", null ],
    [ "UART_Tx_IRQn", "df/d79/struct_u_s_a_r_t___parms_scales.html#a9c4589a497acdfec177e15146e9ca6bd", null ],
    [ "UART_Tx_Port", "df/d79/struct_u_s_a_r_t___parms_scales.html#a25bd28a1fb9125be333fa28e37edb66f", null ],
    [ "UART_Tx_Pin", "df/d79/struct_u_s_a_r_t___parms_scales.html#a8fee2b19df9045804f383e3cc9ef3f08", null ],
    [ "UART_Route", "df/d79/struct_u_s_a_r_t___parms_scales.html#a34f6e76fd4ca955f04bd1203fde184ad", null ],
    [ "Baudrate", "df/d79/struct_u_s_a_r_t___parms_scales.html#a96777c572a3392ffff8e07554ff27d65", null ],
    [ "DataBits", "df/d79/struct_u_s_a_r_t___parms_scales.html#a70857ba71ff684e4dc97aaf2ff53a815", null ],
    [ "Parity", "df/d79/struct_u_s_a_r_t___parms_scales.html#a7c8bf6f9f53a21da7eb46af641346b83", null ],
    [ "StopBits", "df/d79/struct_u_s_a_r_t___parms_scales.html#a3d66706d17d005e4a401b170b353a864", null ]
];