var struct_r_t_c___init___type_def =
[
    [ "enable", "d8/db0/struct_r_t_c___init___type_def.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
    [ "debugRun", "d8/db0/struct_r_t_c___init___type_def.html#a95936f85c6ab1a7f43f02f15f172f1db", null ],
    [ "comp0Top", "d8/db0/struct_r_t_c___init___type_def.html#a7ca3b6a7bbfd2be5fc4be17adf96f560", null ]
];