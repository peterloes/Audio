var struct_f_i_l =
[
    [ "fs", "d8/d3a/struct_f_i_l.html#ae363a794e38f3a9aa1d55b8e3c7fcee7", null ],
    [ "id", "d8/d3a/struct_f_i_l.html#a7b7a6396b2c82ad46c6d8b2bf141a8dd", null ],
    [ "flag", "d8/d3a/struct_f_i_l.html#abb2c49aaa8df55e1e1d8cb0c5e04a3bf", null ],
    [ "pad1", "d8/d3a/struct_f_i_l.html#ac3de9bd412bab7a581223c1c2a95a9bd", null ],
    [ "fptr", "d8/d3a/struct_f_i_l.html#a0f65af32a2d036c560e66177961b9b22", null ],
    [ "fsize", "d8/d3a/struct_f_i_l.html#af70a0afd16367837984d6205cbfca308", null ],
    [ "sclust", "d8/d3a/struct_f_i_l.html#ad5d52f3fde971d2a05ff777a6243c252", null ],
    [ "clust", "d8/d3a/struct_f_i_l.html#ac134c1b4645be670eb5207032e714616", null ],
    [ "dsect", "d8/d3a/struct_f_i_l.html#a272171f74215002aba31a89428f1d290", null ],
    [ "dir_sect", "d8/d3a/struct_f_i_l.html#a5e11faf537370889c867127205f26ad1", null ],
    [ "dir_ptr", "d8/d3a/struct_f_i_l.html#a0071755a7d2cacd3bafbb1bf2dab98a0", null ],
    [ "buf", "d8/d3a/struct_f_i_l.html#a1602edc1ba9d9ae2b583cf55f3492325", null ]
];