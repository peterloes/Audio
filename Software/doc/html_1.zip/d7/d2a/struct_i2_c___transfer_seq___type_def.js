var struct_i2_c___transfer_seq___type_def =
[
    [ "addr", "d7/d2a/struct_i2_c___transfer_seq___type_def.html#a41a6aad09727eb120338c35535a652a6", null ],
    [ "flags", "d7/d2a/struct_i2_c___transfer_seq___type_def.html#a1e87af3c18a2fd36c61faf89949bdc3f", null ],
    [ "data", "d7/d2a/struct_i2_c___transfer_seq___type_def.html#abe222f6d3581e7920dcad5306cc906a8", null ],
    [ "len", "d7/d2a/struct_i2_c___transfer_seq___type_def.html#a8aed22e2c7b283705ec82e0120515618", null ],
    [ "buf", "d7/d2a/struct_i2_c___transfer_seq___type_def.html#abfb161c3665b27b022e1aad07b6de308", null ]
];