var clock_8h =
[
    [ "Clock_Init_TypeDef", "db/dfe/struct_clock___init___type_def.html", "db/dfe/struct_clock___init___type_def" ],
    [ "CLOCK_DEFAULT_START_DATE", "d7/d6e/clock_8h.html#ab39c602516355bba8d2a4df5044efdf2", null ],
    [ "CLOCK_INIT_DEFAULT", "d7/d6e/clock_8h.html#a6aad157a5a2b884e0c434b465256d77d", null ],
    [ "clockInit", "d7/d6e/clock_8h.html#a90216ec79565726dbb875b164e370e1b", null ],
    [ "clockSetStartCalendar", "d7/d6e/clock_8h.html#a05925ead76c924b763c357089ff64a36", null ],
    [ "clockSetStartTime", "d7/d6e/clock_8h.html#a4d26ceb4be24eb47b00830875eb9e744", null ],
    [ "clockGetStartTime", "d7/d6e/clock_8h.html#a4bad6c2bd6b2eb31d536d260fcd65dc5", null ],
    [ "clockOverflow", "d7/d6e/clock_8h.html#a9cc32e2679df7babf577156e973b5872", null ],
    [ "clockSetOverflowCounter", "d7/d6e/clock_8h.html#a9401c4d8e2428541dc42db31d65991ab", null ],
    [ "clockGetOverflowCounter", "d7/d6e/clock_8h.html#ae7630244bbdcc8b257ccffc30c9c1b5b", null ],
    [ "g_rtcStartTime", "d7/d6e/clock_8h.html#aafc9de1c145f8ff56e634db2d0dbd7c9", null ]
];