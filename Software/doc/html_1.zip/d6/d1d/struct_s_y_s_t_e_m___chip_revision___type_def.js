var struct_s_y_s_t_e_m___chip_revision___type_def =
[
    [ "major", "d6/d1d/struct_s_y_s_t_e_m___chip_revision___type_def.html#a5bd4e4c943762926c8f653b6224cced2", null ],
    [ "minor", "d6/d1d/struct_s_y_s_t_e_m___chip_revision___type_def.html#ae2f416b0a34b7beb4ed3873d791ac393", null ]
];