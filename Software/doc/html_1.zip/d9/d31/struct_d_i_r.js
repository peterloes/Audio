var struct_d_i_r =
[
    [ "fs", "d9/d31/struct_d_i_r.html#ae363a794e38f3a9aa1d55b8e3c7fcee7", null ],
    [ "id", "d9/d31/struct_d_i_r.html#a7b7a6396b2c82ad46c6d8b2bf141a8dd", null ],
    [ "index", "d9/d31/struct_d_i_r.html#ab7c5089b70ce76bcd61abe615ed2a42b", null ],
    [ "sclust", "d9/d31/struct_d_i_r.html#ad5d52f3fde971d2a05ff777a6243c252", null ],
    [ "clust", "d9/d31/struct_d_i_r.html#ac134c1b4645be670eb5207032e714616", null ],
    [ "sect", "d9/d31/struct_d_i_r.html#a3e49e0860170e0fd9fc3e891b0d59975", null ],
    [ "dir", "d9/d31/struct_d_i_r.html#a30fe34a14a6efb4c9c04a522f6cf3378", null ],
    [ "fn", "d9/d31/struct_d_i_r.html#a34e961714af3bc25c08d5832cca23204", null ]
];