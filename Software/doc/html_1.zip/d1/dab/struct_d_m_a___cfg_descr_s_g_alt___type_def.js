var struct_d_m_a___cfg_descr_s_g_alt___type_def =
[
    [ "src", "d1/dab/struct_d_m_a___cfg_descr_s_g_alt___type_def.html#a888b1d54333f07bd9da7cec44e0d6398", null ],
    [ "dst", "d1/dab/struct_d_m_a___cfg_descr_s_g_alt___type_def.html#a6598b83f973d0e8bc67fb4c7ee7cd668", null ],
    [ "dstInc", "d1/dab/struct_d_m_a___cfg_descr_s_g_alt___type_def.html#ade331593e9d06957ec020f3280ad47c7", null ],
    [ "srcInc", "d1/dab/struct_d_m_a___cfg_descr_s_g_alt___type_def.html#a650e034d84d7fffc35e29a84f433d6da", null ],
    [ "size", "d1/dab/struct_d_m_a___cfg_descr_s_g_alt___type_def.html#a9fc3b2f84ae9a085eb08733b2e43bc91", null ],
    [ "arbRate", "d1/dab/struct_d_m_a___cfg_descr_s_g_alt___type_def.html#a8818e70c4a68adfee7c8e4da11bea088", null ],
    [ "nMinus1", "d1/dab/struct_d_m_a___cfg_descr_s_g_alt___type_def.html#a04af3109db46ae39c0da5d25a7f39890", null ],
    [ "hprot", "d1/dab/struct_d_m_a___cfg_descr_s_g_alt___type_def.html#acc18bd306b7ff90d0f106dfe42398a47", null ],
    [ "peripheral", "d1/dab/struct_d_m_a___cfg_descr_s_g_alt___type_def.html#a5b33ba7d8d28445cc98a8fc4f7d10bb5", null ]
];