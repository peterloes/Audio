var _d_c_f77_8c =
[
    [ "MOD_DEBUG", "d1/d5d/_d_c_f77_8c.html#a09b84878da212600628fb7648b9068f4", null ],
    [ "DBG_PUTC", "d1/d5d/_d_c_f77_8c.html#a81f8e47007cdb654f3c41f2829d68288", null ],
    [ "DBG_PUTS", "d1/d5d/_d_c_f77_8c.html#aa36da53aa9b0e884b03bca7e3bda37f5", null ],
    [ "FRAME_SEQ_CNT", "d1/d5d/_d_c_f77_8c.html#acd6461756d72a3fddb391136b8c463b5", null ],
    [ "ALARM_MEZ_TO_MESZ", "d1/d5d/_d_c_f77_8c.html#a60c8738199bfad2313f4659985ed73ef", null ],
    [ "ALARM_MESZ_TO_MEZ", "d1/d5d/_d_c_f77_8c.html#af5ea0d5df869138c8a028ecd5aa59fc4", null ],
    [ "DCF_STATE", "d1/d5d/_d_c_f77_8c.html#a2efd349480ecb5874f6125cf06a8d2c6", [
      [ "STATE_OFF", "d1/d5d/_d_c_f77_8c.html#a2efd349480ecb5874f6125cf06a8d2c6a4038ca872e1ed104c16122c365bd3ca0", null ],
      [ "STATE_NO_SIGNAL", "d1/d5d/_d_c_f77_8c.html#a2efd349480ecb5874f6125cf06a8d2c6a43189b443420abbfc1e098059e59a905", null ],
      [ "STATE_SYNC_WAIT", "d1/d5d/_d_c_f77_8c.html#a2efd349480ecb5874f6125cf06a8d2c6a05fe2e4c30a1f5a1fb8e76e12f4cab51", null ],
      [ "STATE_RECV_DATA", "d1/d5d/_d_c_f77_8c.html#a2efd349480ecb5874f6125cf06a8d2c6a4fc2681fe3591e2b97fa6c30f02bb3df", null ],
      [ "STATE_UP_TO_DATE", "d1/d5d/_d_c_f77_8c.html#a2efd349480ecb5874f6125cf06a8d2c6aa13ed942670a855c566ef54dbff29496", null ]
    ] ],
    [ "TimeSynchronize", "d1/d5d/_d_c_f77_8c.html#a690516bdcf5beb08b8296dd5f7925e74", null ],
    [ "SignalSuperVisor", "d1/d5d/_d_c_f77_8c.html#a93f5dd8fcdbbcf9513d869023ba37c0d", null ],
    [ "StateChange", "d1/d5d/_d_c_f77_8c.html#a3ccb16558151e6cb59223cc1d56da050", null ],
    [ "DCF77Init", "d1/d5d/_d_c_f77_8c.html#a1d17e2770e300128ffafabc889f2c5ca", null ],
    [ "DCF77Enable", "d1/d5d/_d_c_f77_8c.html#a5cdb763c0a6dd1bcd38b749306983afb", null ],
    [ "DCF77Disable", "d1/d5d/_d_c_f77_8c.html#aff83024e147a41d779e962834117e836", null ],
    [ "DCF77Handler", "d1/d5d/_d_c_f77_8c.html#a2a1d0430939bdee5839462d050984fd4", null ],
    [ "dcf77", "d1/d5d/_d_c_f77_8c.html#a6382fc196006af6b15395ef9179d7305", null ],
    [ "l_State", "d1/d5d/_d_c_f77_8c.html#abc0ea9c9d590698506c3d76e9d2fb1fc", null ],
    [ "l_TimHdl", "d1/d5d/_d_c_f77_8c.html#aabecf2a05271b7905d6ac0759ee4b8cb", null ],
    [ "l_FrameSeqCnt", "d1/d5d/_d_c_f77_8c.html#af5a1d1a9bf5d54896b4be57e555b1651", null ]
];