var struct_l_e_t_i_m_e_r___init___type_def =
[
    [ "enable", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
    [ "debugRun", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a95936f85c6ab1a7f43f02f15f172f1db", null ],
    [ "rtcComp0Enable", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a6d1aae4b4672b0af1e71e08977139d1e", null ],
    [ "rtcComp1Enable", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a11fa68376cfac9cdacca0defc2e2c52b", null ],
    [ "comp0Top", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a7ca3b6a7bbfd2be5fc4be17adf96f560", null ],
    [ "bufTop", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a1947b5b800c1447625e019013e6ab3d4", null ],
    [ "out0Pol", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a064a6e96e47a0c84ac284fcfc4cf1977", null ],
    [ "out1Pol", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a2c577b8a06beb0b1565d0d393e1c4c97", null ],
    [ "ufoa0", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a6e2e858caccad5bfabd4b9add508cafe", null ],
    [ "ufoa1", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#ac088fd4df2b7a58ed4ae9e3932536096", null ],
    [ "repMode", "d1/d3b/struct_l_e_t_i_m_e_r___init___type_def.html#a957fa5ce399b0cebb6af421f80c2b5e4", null ]
];