var struct_b_a_t___i_n_f_o =
[
    [ "Done", "da/d63/struct_b_a_t___i_n_f_o.html#ac3fdeca3b63101bb46822fca80eacc18", null ],
    [ "Req_1", "da/d63/struct_b_a_t___i_n_f_o.html#a8cd6d145160ab0586d92e96a33a13d68", null ],
    [ "Data_1", "da/d63/struct_b_a_t___i_n_f_o.html#ad391882fd3e22f7ca1515199508d3282", null ],
    [ "Req_2", "da/d63/struct_b_a_t___i_n_f_o.html#a788f178bd01b9f92850e20495d6b95fd", null ],
    [ "Data_2", "da/d63/struct_b_a_t___i_n_f_o.html#a15a95bb63081b89057706c4f0c25cb40", null ],
    [ "Buffer", "da/d63/struct_b_a_t___i_n_f_o.html#af4ba748bbcd6a7513ca1eacdfd469829", null ]
];