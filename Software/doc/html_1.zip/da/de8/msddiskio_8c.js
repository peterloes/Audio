var msddiskio_8c =
[
    [ "disk_initialize", "da/de8/msddiskio_8c.html#a8e429a29bdbb73f5bc9e2ab2335a5112", null ],
    [ "disk_status", "da/de8/msddiskio_8c.html#a21ad8e9a107ea2000705a3edfebaaa2d", null ],
    [ "disk_read", "da/de8/msddiskio_8c.html#a42043c0f462756dbdf1f3bd1bdb5fa50", null ],
    [ "disk_write", "da/de8/msddiskio_8c.html#a0045ef2f87f7c45d77bcdef38eae7b67", null ],
    [ "disk_ioctl", "da/de8/msddiskio_8c.html#ae342f09a55603a5053750e2fd040f4a8", null ],
    [ "stat", "da/de8/msddiskio_8c.html#a80b7ba9e7a0b09396974f38de9d0177c", null ]
];