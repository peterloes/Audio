var _cfg_data_8h =
[
    [ "CFG_VAR_DEF", "d0/d23/struct_c_f_g___v_a_r___d_e_f.html", "d0/d23/struct_c_f_g___v_a_r___d_e_f" ],
    [ "_ID_PARM", "da/d6b/struct___i_d___p_a_r_m.html", "da/d6b/struct___i_d___p_a_r_m" ],
    [ "DUR_INVALID", "d5/d0b/_cfg_data_8h.html#a51d173dd7e416b8213a72b7403ef5614", null ],
    [ "ENUM_DEF", "d5/d0b/_cfg_data_8h.html#aa917f92c18f4f13b560ddcbc228a8c9e", null ],
    [ "ID_PARM", "d5/d0b/_cfg_data_8h.html#a4be471e2413dcdf42027f3f82a4ba089", null ],
    [ "CFG_VAR_TYPE", "d5/d0b/_cfg_data_8h.html#a3a8168f30c55a362d89d1f3f5610fd04", [
      [ "CFG_VAR_TYPE_TIME", "d5/d0b/_cfg_data_8h.html#a3a8168f30c55a362d89d1f3f5610fd04a0030b1ec9aefa35f9ad9e34ee33be54f", null ],
      [ "CFG_VAR_TYPE_DURATION", "d5/d0b/_cfg_data_8h.html#a3a8168f30c55a362d89d1f3f5610fd04ae43832e3817e88c07e1fcd4f9cf26492", null ],
      [ "CFG_VAR_TYPE_ID", "d5/d0b/_cfg_data_8h.html#a3a8168f30c55a362d89d1f3f5610fd04a25f5b7f51d8477425c8bd8c0ff7e4cee", null ],
      [ "CFG_VAR_TYPE_INTEGER", "d5/d0b/_cfg_data_8h.html#a3a8168f30c55a362d89d1f3f5610fd04a1b2f7cdf42dc6ea585968fb1c8eb8464", null ],
      [ "CFG_VAR_TYPE_CONFIG", "d5/d0b/_cfg_data_8h.html#a3a8168f30c55a362d89d1f3f5610fd04a8faba3beb207838013b672210ef7f5b2", null ],
      [ "CFG_VAR_TYPE_ENUM_1", "d5/d0b/_cfg_data_8h.html#a3a8168f30c55a362d89d1f3f5610fd04a2b3a71c60d0e75b2cf3c8525a2e1cae4", null ],
      [ "CFG_VAR_TYPE_ENUM_2", "d5/d0b/_cfg_data_8h.html#a3a8168f30c55a362d89d1f3f5610fd04af2e1eaf640f0319ab0209d289c2cf88d", null ],
      [ "CFG_VAR_TYPE_ENUM_3", "d5/d0b/_cfg_data_8h.html#a3a8168f30c55a362d89d1f3f5610fd04aea1a1c60b72160c9419913c7fe2bb62c", null ],
      [ "CFG_VAR_TYPE_ENUM_4", "d5/d0b/_cfg_data_8h.html#a3a8168f30c55a362d89d1f3f5610fd04a93eaca3027d4ad4b99e7824013f52d2a", null ],
      [ "CFG_VAR_TYPE_ENUM_5", "d5/d0b/_cfg_data_8h.html#a3a8168f30c55a362d89d1f3f5610fd04ac0e608c86aab44ad898f49bb97ee4739", null ],
      [ "END_CFG_VAR_TYPE", "d5/d0b/_cfg_data_8h.html#a3a8168f30c55a362d89d1f3f5610fd04a3783128afeeabc3ecd8e9c4a942a8576", null ]
    ] ],
    [ "CfgDataInit", "d5/d0b/_cfg_data_8h.html#a2e249b6ce14a90a28af698c242662f5d", null ],
    [ "CfgRead", "d5/d0b/_cfg_data_8h.html#a6dd69353a28917dbadc38893b31a0eab", null ],
    [ "CfgLookupID", "d5/d0b/_cfg_data_8h.html#a51632e134fb8951653054ee123d399cd", null ],
    [ "CfgDataShow", "d5/d0b/_cfg_data_8h.html#a95e416e175f697fd99728be156439e24", null ]
];