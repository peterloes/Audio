var struct_p_w_r___o_u_t___d_e_f =
[
    [ "BitBandAddr", "d2/d9a/struct_p_w_r___o_u_t___d_e_f.html#ad22de4ec361cb9d7f6f96e32b921a776", null ],
    [ "HighActive", "d2/d9a/struct_p_w_r___o_u_t___d_e_f.html#a1bf5c8966db5aa5012eb3f4d356f80d7", null ]
];