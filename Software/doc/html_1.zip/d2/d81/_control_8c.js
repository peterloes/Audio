var _control_8c =
[
    [ "PWR_OUT_DEF", "d2/d9a/struct_p_w_r___o_u_t___d_e_f.html", "d2/d9a/struct_p_w_r___o_u_t___d_e_f" ],
    [ "GPIO_BIT_ADDR", "d2/d81/_control_8c.html#a85a066138b32e08d0665f75f6597dbfb", null ],
    [ "GPIO_BIT_ADDR_TO_PORT", "d2/d81/_control_8c.html#aaef3e8c4d4ecf623d9ed8e7c7508831a", null ],
    [ "GPIO_BIT_ADDR_TO_PIN", "d2/d81/_control_8c.html#a7f7b3e5058554a40125f69c6cfdf14ba", null ],
    [ "PowerControl", "d2/d81/_control_8c.html#a0de5b4dde5abb3fb9ef4af05c3929a75", null ],
    [ "ControlInit", "d2/d81/_control_8c.html#a6b08b89da482cdbc5a18743835b2d700", null ],
    [ "ClearConfiguration", "d2/d81/_control_8c.html#ad36751837af7ec22750c289b9b755bfb", null ],
    [ "ControlUpdateID", "d2/d81/_control_8c.html#abfad61d13191a6cd185361f64e0bd941", null ],
    [ "ControlPowerFailHandler", "d2/d81/_control_8c.html#a3a7749219117b7b402d5c4515d6fe48d", null ],
    [ "PowerOutput", "d2/d81/_control_8c.html#a5516e9d442dcc67f7205c5f6c095f4f9", null ],
    [ "IsPowerOutputOn", "d2/d81/_control_8c.html#a9a7c3269f7b44d90b4b6aaa600e54bb6", null ],
    [ "g_enum_PowerOutput", "d2/d81/_control_8c.html#a40abdf6abc9b3d3cb83717170c9207b3", null ],
    [ "l_PwrOutDef", "d2/d81/_control_8c.html#ac78a0ded2c784e294524bb0a4600d08b", null ],
    [ "l_CfgVarList", "d2/d81/_control_8c.html#a7178369c933a2b613d12ffecb34b98d7", null ],
    [ "l_EnumList", "d2/d81/_control_8c.html#accb8a87c94490168ccc1fb6c7e16ff1e", null ]
];