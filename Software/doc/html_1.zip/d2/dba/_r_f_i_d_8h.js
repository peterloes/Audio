var _r_f_i_d_8h =
[
    [ "RFID_CONFIG", "d4/d4d/struct_r_f_i_d___c_o_n_f_i_g.html", "d4/d4d/struct_r_f_i_d___c_o_n_f_i_g" ],
    [ "RFID_DISPLAY_UPDATE_WHEN_ABSENT", "d2/dba/_r_f_i_d_8h.html#a6403a545f800ef1aa57bd9aeede5d66f", null ],
    [ "RFID_TRIGGERED_BY_LIGHT_BARRIER", "d2/dba/_r_f_i_d_8h.html#a5a4c0617d02e50b67c6da96c0dd5ec9f", null ],
    [ "DFLT_RFID_ABSENT_DETECT_TIMEOUT", "d2/dba/_r_f_i_d_8h.html#acc70bb2c849eba0a95f353aadb600219", null ],
    [ "DFLT_RFID_POWER_OFF_TIMEOUT", "d2/dba/_r_f_i_d_8h.html#a2f3d51479340ea459fe8fda421f18a7b", null ],
    [ "DFLT_RFID_DETECT_TIMEOUT", "d2/dba/_r_f_i_d_8h.html#ac2664aae42ce0c62cd6d2c44a0e3811a", null ],
    [ "RFID_TYPE", "d2/dba/_r_f_i_d_8h.html#ad5111b17933e6eff127b935003236ae1", [
      [ "RFID_TYPE_NONE", "d2/dba/_r_f_i_d_8h.html#ad5111b17933e6eff127b935003236ae1aa12f680657ec462c1ca5e321b6ba600b", null ],
      [ "RFID_TYPE_SR", "d2/dba/_r_f_i_d_8h.html#ad5111b17933e6eff127b935003236ae1a33a565090cfc7eb44691f31a0f630c45", null ],
      [ "RFID_TYPE_LR", "d2/dba/_r_f_i_d_8h.html#ad5111b17933e6eff127b935003236ae1a9bd165bb71a72a15a720240d0e5d4e95", null ],
      [ "NUM_RFID_TYPE", "d2/dba/_r_f_i_d_8h.html#ad5111b17933e6eff127b935003236ae1a0330e9443820d3f5d1fba481f6496c51", null ]
    ] ],
    [ "RFID_Init", "d2/dba/_r_f_i_d_8h.html#aa171c72a404c36894017be00e8af3284", null ],
    [ "IsRFID_Active", "d2/dba/_r_f_i_d_8h.html#a6e412fd9fc17c30ed393b3b88219d41c", null ],
    [ "RFID_Enable", "d2/dba/_r_f_i_d_8h.html#ab0f9a1d864cbb7620604b198840c1839", null ],
    [ "RFID_Disable", "d2/dba/_r_f_i_d_8h.html#a36d7d6556cc9b4c175074b5337daed62", null ],
    [ "IsRFID_Enabled", "d2/dba/_r_f_i_d_8h.html#a7d067e0bca7cdf561dd3a5e6b6a00562", null ],
    [ "RFID_TimedDisable", "d2/dba/_r_f_i_d_8h.html#a0913a23091bbe1bb3939443da8e3d963", null ],
    [ "RFID_Check", "d2/dba/_r_f_i_d_8h.html#aec53585d9563a582495447b7098108e6", null ],
    [ "RFID_PowerOff", "d2/dba/_r_f_i_d_8h.html#a3b33947c8daf2d555030ae3b6c1227df", null ],
    [ "RFID_PowerFailHandler", "d2/dba/_r_f_i_d_8h.html#aeaeabf4a10507ba899a883dc557b08cd", null ],
    [ "g_RFID_PwrOffTimeout", "d2/dba/_r_f_i_d_8h.html#afc67b58e5c1781eb26a5dbe4e2d8969d", null ],
    [ "g_RFID_DetectTimeout", "d2/dba/_r_f_i_d_8h.html#af3529f87faa276002082ed14f6c514f8", null ],
    [ "g_RFID_Type", "d2/dba/_r_f_i_d_8h.html#a9eb55955c97715449d1da251aaf0be87", null ],
    [ "g_RFID_Power", "d2/dba/_r_f_i_d_8h.html#a08c6bd38e679071803a109ec68a9f12c", null ],
    [ "g_RFID_AbsentDetectTimeout", "d2/dba/_r_f_i_d_8h.html#a8cd118cc86a48e951e0936dd8b496662", null ],
    [ "g_enum_RFID_Type", "d2/dba/_r_f_i_d_8h.html#a26590948b5c9696c30067abfdcd553f9", null ],
    [ "g_Transponder", "d2/dba/_r_f_i_d_8h.html#aa61d56a9c62ec509e6c671e7515e568a", null ]
];