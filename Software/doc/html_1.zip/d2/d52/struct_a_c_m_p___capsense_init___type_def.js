var struct_a_c_m_p___capsense_init___type_def =
[
    [ "fullBias", "d2/d52/struct_a_c_m_p___capsense_init___type_def.html#a925773c9f41ac55d361e5714bdeb1b3b", null ],
    [ "halfBias", "d2/d52/struct_a_c_m_p___capsense_init___type_def.html#acbb92db3a14fd71e0eb0d0fd9d9df89b", null ],
    [ "biasProg", "d2/d52/struct_a_c_m_p___capsense_init___type_def.html#a8f814b4647e7cdf6dfb80ae4336fba94", null ],
    [ "warmTime", "d2/d52/struct_a_c_m_p___capsense_init___type_def.html#a47a293117841a52b75a93a5178cf97cc", null ],
    [ "hysteresisLevel", "d2/d52/struct_a_c_m_p___capsense_init___type_def.html#a496bc8740e148cc441896a1a6f3728bf", null ],
    [ "resistor", "d2/d52/struct_a_c_m_p___capsense_init___type_def.html#a387d427aa1028c5d83a47b165a685cbc", null ],
    [ "lowPowerReferenceEnabled", "d2/d52/struct_a_c_m_p___capsense_init___type_def.html#abb4beda3210cfcbd13babb6b3d594949", null ],
    [ "vddLevel", "d2/d52/struct_a_c_m_p___capsense_init___type_def.html#a75dbd54b3d3aff2ab2027807d07c678d", null ],
    [ "enable", "d2/d52/struct_a_c_m_p___capsense_init___type_def.html#ac842b6c1dcb3b1f11b611620199dc55c", null ]
];