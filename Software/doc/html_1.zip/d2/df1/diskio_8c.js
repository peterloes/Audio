var diskio_8c =
[
    [ "disk_initialize", "d2/df1/diskio_8c.html#a8e429a29bdbb73f5bc9e2ab2335a5112", null ],
    [ "disk_status", "d2/df1/diskio_8c.html#a21ad8e9a107ea2000705a3edfebaaa2d", null ],
    [ "disk_read", "d2/df1/diskio_8c.html#a42043c0f462756dbdf1f3bd1bdb5fa50", null ],
    [ "disk_write", "d2/df1/diskio_8c.html#a0045ef2f87f7c45d77bcdef38eae7b67", null ],
    [ "disk_ioctl", "d2/df1/diskio_8c.html#ae342f09a55603a5053750e2fd040f4a8", null ],
    [ "stat", "d2/df1/diskio_8c.html#a13fcff09747acc03a6f53cebfd53f196", null ],
    [ "CardType", "d2/df1/diskio_8c.html#ac385b2a600ad54272bcd7313afb9b966", null ]
];